# think-multi-app

用于ThinkPHP6+的多应用支持

## 安装

~~~
composer require topthink/think-multi-app
~~~

## 使用

用法参考ThinkPHP6完全开发手册[多应用模式](https://www.kancloud.cn/manual/thinkphp6_0/1297876)章节。

