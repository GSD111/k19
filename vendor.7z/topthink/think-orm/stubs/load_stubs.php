<?php

if (!\class_exists('think\Exception')) {
    require __DIR__ . '/Exception.php';
}

if (!\class_exists('think\Facade')) {
    require __DIR__ . '/Facade.php';
}